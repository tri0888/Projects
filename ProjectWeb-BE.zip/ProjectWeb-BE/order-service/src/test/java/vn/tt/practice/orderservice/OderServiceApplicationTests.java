package vn.tt.practice.orderservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OderServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
